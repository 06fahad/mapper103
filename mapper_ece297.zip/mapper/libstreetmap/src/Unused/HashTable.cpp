///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//#include <HashTable.h>
//#include <LatLon.h>
//#include <m1.h>
//#include <GlobalVariables.h>
//using namespace std;
//
////those constant are used to avoid modification on the global variables
//int findHashValue(LatLon my_position,const double basey_,const double basex_,const double increment_,const double averagelat_,const int sizex_ ){
//    int hashy,hashx;
//    
//    hashy=floor((my_position.lat()*DEG_TO_RAD*EARTH_RADIUS_IN_METERS/1000-basey_)/increment_);
//    hashx=floor((my_position.lon()*cos(averagelat_*DEG_TO_RAD)*DEG_TO_RAD/1000*EARTH_RADIUS_IN_METERS-basex_)/increment_);
//    
//    if(hashy>sizey)
//        
//        //Diagnostic message
//        cout<<"Y value exceed limits"<<endl;
//    
//    
//    if(hashx>sizex)
//        
//        //Diagnostic message
//        cout<<"X value exceed limits"<<endl;
//    
//    return (hashx+hashy*sizex);
//}
//
//double findXfromLatLon(LatLon my_position){
//    return my_position.lon()*cos(averagelat*DEG_TO_RAD)*DEG_TO_RAD*EARTH_RADIUS_IN_METERS/1000;
//    
//    
//}
//
//double findYfromLatLon(LatLon my_position){
//    return my_position.lat()*DEG_TO_RAD*EARTH_RADIUS_IN_METERS/1000;
//}
//
//double findShortestDistanceInOneSquare(int HashValue,LatLon my_position,int& index,const vector<vector<unsigned>> HashTable,const vector<LatLon> position_vector,double& shortest){
//    if(HashValue<0)
//        
//        //Diagnostic message
//        cout<<"Invalid Hash Value: negative"<<endl;
//    
//    
//    else if(HashValue>sizex*sizey)
//        
//        //Diagnostic message
//        cout<<"Invalid Hash Value: exceed high limitation"<<endl;
//
//    
//    double distance;
//    
//    //cout<<"Check Point 2"<<endl;
//    for(unsigned i=0;i<HashTable[HashValue].size();i++){
//        distance = find_distance_between_two_points(position_vector[HashTable[HashValue][i]], my_position);
//        //HashTable[i] is a unsigned e.g index for the POI or Intersection. Place that index into either POI_LatLon or 
//        //Intersection_LatLon will give the LatLon back
//        
//        if (distance < shortest) {
//            
//            //Diagnostic message
//            cout<<"The distance is " << distance<<"The shortest is "<<shortest<<endl;
//            
//            shortest = distance;
//            index = HashTable[HashValue][i];
//            
//            //Diagnostic message
//            cout<<"update index to "<<index<<"    "<<"The distance is " << distance<<"The shortest is "<<shortest<<endl;
//            
//    }
//        //cout<<"check point 3"<<endl;
//}
//    return shortest;
//}
//
//
//vector <int> findNewVerticies(LatLon my_position, double shortest_distance){
//    double myx= findXfromLatLon(my_position);
//    double myy= findYfromLatLon(my_position);
//    //cout<<shortest_distance/1000<<endl;
//    double TLx = myx-shortest_distance/1000;  //left boundary
//    if(TLx<basex)
//        TLx=basex+0.5*increment;
//    else if(TLx>(basex+sizex*increment))
//        TLx=basex+sizex*increment-0.5*increment;
//    
//    double TLy = myy+shortest_distance/1000;//top boundary
//    if(TLy<basey)
//        TLy=basey+0.5*increment;
//    else if(TLx>(basey+sizey*increment))
//        TLx=basey+sizey*increment-0.5*increment;
//   
//    double BRx = myx+shortest_distance/1000;//right boundary
//    if(BRx<basex)
//        BRx=basex+0.5*increment;
//    else if(BRx>(basex+sizex*increment))
//        BRx=basex+sizex*increment-0.5*increment;
//   
//    double BRy = myy-shortest_distance/1000;//bottom boundary
//    if(BRy<basey)
//        BRy=basey+0.5*increment;
//    else if(BRy>(basey+sizey*increment))
//        BRy=basey+sizey*increment-0.5*increment;
//   
//    int hTLx=floor((TLx-basex)/increment);
//    int hTLy=floor((TLy-basey)/increment);
//    int hTRx=floor((BRx-basex)/increment);
//    int hTRy=floor((TLy-basey)/increment);
//    int hBLx=floor((TLx-basex)/increment);
//    int hBLy=floor((BRy-basey)/increment);
//
//    int hTL=hTLx*hTLy;//hash value for new top left vertex
//    int hTR=hTRx*hTRy;//hash value for new top right vertex
//    int hBL=hBLx*hBLy;//hash value for new bottom left vertex
//
//    vector<int> ThreeVerticies;
//    ThreeVerticies.push_back(hBLx);//ThreeVerticies[0]
//    ThreeVerticies.push_back(hBLy);//[1]
//    ThreeVerticies.push_back(hTLx);//[2]
//    ThreeVerticies.push_back(hTLy);//[3]
//    ThreeVerticies.push_back(hTRx);//[4]
//    ThreeVerticies.push_back(hTRy);//[5]
//    
//    
//    return ThreeVerticies;
//    
//
//} 
//
//double searchThroughRectangleForShortestDistance(vector<int> ThreeVerticies,LatLon my_position,int& index,const vector<vector<unsigned>> HashTable,const vector<LatLon> position_vector,double& shortest){
//    double distance;
//    
//    
//    int hBLx=ThreeVerticies[0];
//    int hBLy=ThreeVerticies[1];
//    int hTLx=ThreeVerticies[2];
//    int hTLy=ThreeVerticies[3];
//    int hTRx=ThreeVerticies[4];
//    int hTRy=ThreeVerticies[5];
////    for(int i=0;i<6;i++){
////        cout<<ThreeVerticies[i]<<"ThreeVerticies"<<endl;
////    }
//    int hashy,hashx;
//    hashy=floor((my_position.lat()*DEG_TO_RAD*EARTH_RADIUS_IN_METERS/1000-basey)/increment);
//    hashx=floor((my_position.lon()*cos(averagelat*DEG_TO_RAD)*DEG_TO_RAD/1000*EARTH_RADIUS_IN_METERS-basex)/increment);
//    //cout<<"In Rectangular search "<<hashx<<" "<<hTRx<<" "<<hashy<<" "<<hTLy<<endl;
//    int x,y;
//    x=hTLx;
//    y=hBLy;
//    
//    //Diagnostic message
//    cout<<endl<<"Searching through rectangle";
//    
//    //Diagnostic message
//    cout<<x<<" "<<hTRx<<", "<<y<<" "<<hTLy<<endl;
//    
//    while(x<=hTRx){
//        while(y<=hTLy){
//            distance=findShortestDistanceInOneSquare((x+y*sizex),my_position,index,HashTable,position_vector,shortest);
//            //(int HashValue,LatLon my_position,int* index,vector<vector<unsigned>> HashTable,vector<LatLon> position_vector)
//            if(distance<shortest)
//                shortest=distance;
//            y++;
//        }
//        x++;
//    }
//    //cout<<index<<endl;
//    return shortest;
//}
//
//
//
//
//
