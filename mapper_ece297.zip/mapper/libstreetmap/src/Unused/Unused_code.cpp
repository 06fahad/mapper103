/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
////////////////////////
//   UNUSED CODE      //
//    M2  BELOW       //
////////////////////////


//void draw_streets_name(int level_of_detail) {
//    vector<value> intersection_in_box;
//    vector<unsigned> all_segs_to_int;
//    list<unsigned> segments_in_box;
//    vector<unsigned> segments_index_in_box;
//
//
//    //t_point my_pos = get_visible_world().get_center();
//
//    point bottomleft(get_visible_world().bottom_left().x, get_visible_world().bottom_left().y);
//    point topright(get_visible_world().top_right().x, get_visible_world().top_right().y);
//    bg::model::box<point> screen(bottomleft, topright);
//    //find all the intersection on the map
//    IntersectionRtree.query(bgi::intersects(screen), std::back_inserter(intersection_in_box));
//    //push those values into the 
//    for (unsigned i = 0; i < intersection_in_box.size(); i++) {
//        all_segs_to_int = find_intersection_street_segments(intersection_in_box[i].second);
//        for (unsigned j = 0; j < all_segs_to_int.size(); j++) {
//            segments_in_box.push_back(all_segs_to_int[j]);
//        }
//    }
//
//    segments_in_box.sort();
//    segments_in_box.unique(); //we went through all the segments twice so now we remove all the duplicate
//    list<unsigned>::iterator it = segments_in_box.begin();
//
//    for (unsigned i = 0; i < segments_in_box.size(); i++) { //populate a vector with all segInfo we will need
//        segments_index_in_box.push_back(*it);
//        advance(it, 1);
//
//    }
//
//    for (unsigned i = 0; i < segments_index_in_box.size(); i++) {
//        if (street_segment_LOD[segments_index_in_box[i]] > level_of_detail) {
//            draw_street_segment_name(level_of_detail, segments_index_in_box[i]);
//        }
//    }







//Subways

//    cout <<OSMIDVec.size()<<endl;
    //    for (unsigned i = 0; i < OSMIDVec.size(); i++) {
    //        auto foundLatLon = OSMID_LatLon_unordered_map.find(OSMIDVec[i]);
    //        if (foundLatLon != OSMID_LatLon_unordered_map.end()) {
    //            count++;
    //            vector <double> coords = LatLon_to_XY(foundLatLon->second.lat(), foundLatLon->second.lon());
    //            setlinestyle(SOLID, ROUND);
    //            setcolor(RED);
    //            setlinewidth(2);
    //            t_point point = t_point(coords[0], coords[1]);
    //            drawline(point, point);
    //        }
    //        cout <<"i: "<<endl;
    //    }

    // cout << "subways are: " << subwaysOn << endl;

    //cout << count << endl;
    //    cout << subwayMap_OSMID_LatLon.size()<<endl;
    //    for (unordered_map<OSMID, LatLon>::iterator iter = subwayMap_OSMID_LatLon.begin(); iter != subwayMap_OSMID_LatLon.end(); iter++) {
    //        vector <double> nodeCoords = LatLon_to_XY (iter->second.lat(), iter->second.lon());
    //        
    //        setlinestyle (DASHED, ROUND);
    //        setcolor (RED);
    //        setlinewidth(2);
    //        t_point point = t_point (nodeCoords[0], nodeCoords[1]);
    //        drawline (point, point);
    //    }




//void draw features(){
//        //        for (unsigned i = 0; i < numOfFeatures - 1; i++) {
//    //            switch (feature_data[i].type) {
//    //                case 0: //unknown
//    //                    setcolor(0, 0, 0, 255);
//    //                    break;
//    //                case 1: //Park,
//    //                    setcolor(t_color (greenColor));
//    //                    break;
//    //                case 2: //Beach,
//    //                    setcolor(219, 219, 103, 255);
//    //                    break;
//    //                case 3: //Lake,
//    //                    setcolor(oceanColor);
//    //                    break;
//    //                case 4://river
//    //                    setcolor(t_color (141, 176, 240));
//    //                    break;
//    //                case 5://island
//    //                    setcolor(232, 221, 151, 255);
//    //                    break;
//    //                case 6://shoreline
//    //                    setcolor(173, 162, 138, 255);
//    //                    break;
//    //                case 7://building
//    //                    setcolor(buildingColor);
//    //                    break;
//    //                case 8://greenspace
//    //                    setcolor(greenColor);
//    //                    break;
//    //                case 9://golfcourse
//    //                    setcolor(t_color (45, 105, 40));
//    //                    break;
//    //                case 10://stream
//    //                    setcolor(t_color(streamColor));
//    //                    break;
//    //
//    //                default:
//    //                    setcolor(0, 0, 0, 255);
//    //
//    //            }
//
//    //            if (j == 0 && (feature_data[i].type == 3 && feature_data[i].name != "<noname>")) {//layer1 lake
//    //
//    //                fillpoly(&feature_data[i].boundaryPoints[0], (feature_data[i].boundaryPoints.size()));
//    //            } else if (j == 2 && (feature_data[i].type == 5)) {//layer2 island
//    //                fillpoly(&feature_data[i].boundaryPoints[0], feature_data[i].boundaryPoints.size());
//    //            } else if (j == 1 && (feature_data[i].type == 6 || feature_data[i].type == 2)) {//layer2 island
//    //                fillpoly(&feature_data[i].boundaryPoints[0], feature_data[i].boundaryPoints.size());
//    //            } else if (j == 3 && (feature_data[i].type == 1 || feature_data[i].type == 9 || feature_data[i].type == 8)) {//layer3 Park
//    //                fillpoly(&feature_data[i].boundaryPoints[0], feature_data[i].boundaryPoints.size());
//    //            } else if (j == 4 && (feature_data[i].type == 4)) {//layer4 river
//    //                for (unsigned k = 0; k < feature_data[i].boundaryPoints.size() - 1; k++) {
//    //                    drawline(feature_data[i].boundaryPoints[k], feature_data[i].boundaryPoints[k + 1]);
//    //                }
//    //            } else if (j == 5 && (feature_data[i].type == 10) && level_of_detail < 7) {//layer4 stream
//    //                for (unsigned k = 0; k < feature_data[i].boundaryPoints.size() - 1; k++) {
//    //                    drawline(feature_data[i].boundaryPoints[k], feature_data[i].boundaryPoints[k + 1]);
//    //                }
//    //            } else if (j == 6 && (feature_data[i].type == 7) && level_of_detail < 7) {//layer5 building
//    //                fillpoly(&feature_data[i].boundaryPoints[0], feature_data[i].boundaryPoints.size());
//    //            }
//    //        }
//    //    }
//
//}

//void draw_streets_name(int level_of_detail) {
//    vector<value> intersection_in_box;
//    vector<unsigned> all_segs_to_int;
//    list<unsigned> segments_in_box;
//    vector<unsigned> segments_index_in_box;
//
//
//    //t_point my_pos = get_visible_world().get_center();
//
//    point bottomleft(get_visible_world().bottom_left().x, get_visible_world().bottom_left().y);
//    point topright(get_visible_world().top_right().x, get_visible_world().top_right().y);
//    bg::model::box<point> screen(bottomleft, topright);
//    //find all the intersection on the map
//    IntersectionRtree.query(bgi::intersects(screen), std::back_inserter(intersection_in_box));
//    //push those values into the 
//    for (unsigned i = 0; i < intersection_in_box.size(); i++) {
//        all_segs_to_int = find_intersection_street_segments(intersection_in_box[i].second);
//        for (unsigned j = 0; j < all_segs_to_int.size(); j++) {
//            segments_in_box.push_back(all_segs_to_int[j]);
//        }
//    }
//
//    segments_in_box.sort();
//    segments_in_box.unique(); //we went through all the segments twice so now we remove all the duplicate
//    list<unsigned>::iterator it = segments_in_box.begin();
//
//    for (unsigned i = 0; i < segments_in_box.size(); i++) { //populate a vector with all segInfo we will need
//        segments_index_in_box.push_back(*it);
//        advance(it, 1);
//
//    }
//
//    for (unsigned i = 0; i < segments_index_in_box.size(); i++) {
//        if (street_segment_LOD[segments_index_in_box[i]] > level_of_detail) {
//            draw_street_segment_name(level_of_detail, segments_index_in_box[i]);
//        }
//    }
//
//    //    //start to draw the text on the street 
//    //    t_point centreOfText;
//    //    float width,height,rotation;
//    //        
//    //    
//    //    for(int i =0;i<SegInfo_in_box.size(); i++){
//    //        int numberOfSeg=SegInfo_in_box[i].curvePointCount;
//    //        if(numberOfSeg<3){
//    //            centreOfText.x=(LatLon_to_XY(SegInfo_in_box[i].from).x+LatLon_to_XY(SegInfo_in_box[i].to).x)/2;
//    //            centreOfText.y=(LatLon_to_XY(SegInfo_in_box[i].from).y+LatLon_to_XY(SegInfo_in_box[i].to).y)/2;
//    //            rotation=atan((LatLon_to_XY(SegInfo_in_box[i].from).y-LatLon_to_XY(SegInfo_in_box[i].to).y)/(LatLon_to_XY(SegInfo_in_box[i].from).x-LatLon_to_XY(SegInfo_in_box[i].to).x))
//    //            rotation=rotation* 180/PI;
//    //            settextrotation(rotation);
//    //            drawtext(centreOfText.x,centreOfText.y,street_name_of_segments[i],width,height);
//    //        }
//    //        
//    //        else if(numberOfSeg<10){
//    //            int center=floor(numberOfSeg/2);
//    //            centreOfText.x=(LatLon_to_XY(street_seg_curve_point[segments_in_box[i][center]]).x+LatLon_to_XY(street_seg_curve_point[segments_in_box[i][center]]).x)/2;
//    //            centreOfText.y=(LatLon_to_XY(street_seg_curve_point[segments_in_box[i][center]]).y+LatLon_to_XY(street_seg_curve_point[segments_in_box[i][center]]).y)/2;
//    //            rotation=atan(
//    //                    (LatLon_to_XY(street_seg_curve_point[segments_in_box[i][center+1]]).y-LatLon_to_XY(street_seg_curve_point[segments_in_box[i][center-1]]).y)/
//    //                    (LatLon_to_XY(street_seg_curve_point[segments_in_box[i][center+1]]).x-LatLon_to_XY(street_seg_curve_point[segments_in_box[i][center-1]]).x)
//    //                    )
//    //            rotation=rotation* 180/PI;
//    //            settextrotation(rotation);
//    //            drawtext(centreOfText.x,centreOfText.y,street_name_of_segments[i],width,height);
//    //        }
//    //        else{
//    //        for(int j=4;j<numberOfSeg-1;j=j+5){
//    //            centreOfText.x=(LatLon_to_XY(street_seg_curve_point[segments_in_box[i][j]]).x+LatLon_to_XY(street_seg_curve_point[segments_in_box[i][j]]).x)/2;
//    //            centreOfText.y=(LatLon_to_XY(street_seg_curve_point[segments_in_box[i][j]]).y+LatLon_to_XY(street_seg_curve_point[segments_in_box[i][j]]).y)/2;
//    //            rotation=atan(
//    //                    (LatLon_to_XY(street_seg_curve_point[segments_in_box[i][j+1]]).y-LatLon_to_XY(street_seg_curve_point[segments_in_box[i][j-1]]).y)/
//    //                    (LatLon_to_XY(street_seg_curve_point[segments_in_box[i][j+1]]).x-LatLon_to_XY(street_seg_curve_point[segments_in_box[i][j-1]]).x)
//    //                    )
//    //            rotation=rotation* 180/PI;
//    //            settextrotation(rotation);
//    //            drawtext(centreOfText.x,centreOfText.y,street_name_of_segments[i],width,height);
//    //        }
//    //        }
//    //    }
//
//
//}

//void drawSearchBar() {
//    //    t_bound_box visibleWorldCoords = get_visible_world();
//    //    t_point topRight = visibleWorldCoords.top_right();
//    //    
//    //    setcolor (RED);
//    //    fillrect(topRight.x - 500, topRight.y - 50, topRight.x, topRight.y);
//
//    set_coordinate_system(GL_SCREEN);
//    setcolor(t_color(255, 0, 0));
//    setlinestyle(SOLID);
//    fillrect(0, 0, 0, 100);
//    if (findTextOff == true) drawtext(100, 30, "Find");
//    // Specifying FLT_MAX for the size limits on the text (in world coordinates) so
//    // it will always be drawn.
//    //        drawtext (55, 33, "Screen coord");
//    //        drawtext (55, 66, "Fixed loc");
//    set_coordinate_system(GL_WORLD);
//}










////////////////////////
//OLD UNOPTIMIZED CODE//
//    M1  BELOW       //
////////////////////////

//double find_street_segment_travel_time(unsigned street_segment_id) {
//    double traveltime = street_seg_length[street_segment_id] / (street_seg_info[street_segment_id].speedLimit / 3.6);
//    return traveltime;
//}

//double find_street_segment_length(unsigned street_segment_id){
//    
//    //Initial return value
//    double length = 0;
//    
//    if (street_seg_curve_point_num[street_segment_id] == 0){
//        
//        distance = 
//        
//    }
//    
//    
//}


//double find_street_segment_length(unsigned street_segment_id) {
//    StreetSegmentInfo SegInfo = street_seg_info[street_segment_id];
//    double distance = 0;
//    if (SegInfo.curvePointCount == 0) {
//        distance = find_distance_between_two_points(Intersection_LatLon[SegInfo.from], Intersection_LatLon[SegInfo.to]);
//
//        return (distance);
//    } else {
//
//        for (unsigned i = 0; i < SegInfo.curvePointCount - 1; i++) {
//            distance = distance + find_distance_between_two_points(
//                    street_seg_curve_point[street_segment_id][i],
//                    street_seg_curve_point[street_segment_id][i + 1]
//                    ); //Distance between all the curves points. From point and to point are not included inside the curve points
//        }
//        distance = distance + find_distance_between_two_points(
//                Intersection_LatLon[SegInfo.from],
//                street_seg_curve_point[street_segment_id][0]
//                ); //Adding the distance from from to 1st curve point
//        distance = distance + find_distance_between_two_points(
//                street_seg_curve_point[street_segment_id][SegInfo.curvePointCount - 1],
//                Intersection_LatLon[SegInfo.to]
//                ); //Adding the distance from the last curve point to to
//    }
//
//    //cout << "Street Segment length " << distance << endl;
//    return (distance);
//}

//vector<unsigned> find_intersection_street_segments(unsigned intersection_id) {
//    vector<unsigned> street_segments;
//    unsigned num_streets_on_intersection = street_seg_count[intersection_id];
////
////    //cout <<"number of streets segments connected to intersection: " <<num_streets_on_intersection<<endl;
////
//    for (unsigned i = 0; i < num_streets_on_intersection; i++) {
//        street_segments.push_back(street_segments_for_intersection_id[intersection_id][i]);
//    }
//    
//    
//    return (street_segments);
//}


////Returns all intersections along the a given street
//std::vector < unsigned > find_all_street_intersections(unsigned street_id) {
//    //Diagnostic Message:   
//    //cout << "Find_all_street_intersections has been called" << endl;
//
//    //Initializing the two vectors we are going to use
//    std::vector <unsigned> streetSegs = find_street_street_segments(street_id); //Getting the segments of the street 
//    std::vector <unsigned> allIntersections; //Initializing the return vector
//
//    //Two flags used to check for duplicate intersections
//    bool presentFlagTo = false;
//    bool presentFlagFrom = false;
//
//    //Cycle through the segments to find connected intersections
//    for (unsigned segCount = 0; segCount < streetSegs.size(); segCount++) {
//
//        //Temp variable to get segment info
//        StreetSegmentInfo segInfo = getStreetSegmentInfo(streetSegs[segCount]); //Temp variable to store seg info
//
//
//        // Duplicate checking, order(N)
//        // Cycles through found intersections and checks for already present
//        for (unsigned tempCount = 0; tempCount < allIntersections.size(); tempCount++) {
//
//            // Checks for pre segment intersection duplicate
//            if (allIntersections[tempCount] == segInfo.from) {
//                //cout << segInfo.from << endl;
//                presentFlagFrom = true;
//            }
//
//            // Checks for post segment intersection duplicate
//            if (allIntersections[tempCount] == segInfo.to) {
//                presentFlagTo = true;
//                //cout << segInfo.to << endl;
//            }
//        }
//
//        //Following six lines adds the to/from intersection if they are not already there to the return vector
//        if (presentFlagTo == false) {
//            allIntersections.push_back(segInfo.to);
//        }
//        if (presentFlagFrom == false) {
//            allIntersections.push_back(segInfo.from);
//        }
//
//        //Second Duplicate catcher since the first missed one
//        allIntersections.erase(unique(allIntersections.begin(), allIntersections.end()), allIntersections.end());
//
//        presentFlagTo = false;
//        presentFlagFrom = false;
//
//        //Freeing the temp Info pointer
//
//    }
//    
//    //Diagnostic Message:
//    //cout << "find_all_street_intersections success" << endl;
//
//
//    //final return
//    return allIntersections;
//
//}

////If the names match we add it to the vector
////if this is never true the vector is empty (size of 0)
//vector<unsigned> find_street_ids_from_name(std::string street_name) {
//    
//    
//    vector<unsigned> streetsWithThisName; //Creating the vector we will return
//
//    //Cycling through the streets by streetID (0 to numOfStreets -1)
//    
//    
//    for (unsigned counter = 0; counter < numOfStreets; counter++) {
//
//        if (street_names_by_index[counter] == street_name) {
//            streetsWithThisName.push_back(counter); //Adding ID into the vector
//            //cout << "counter";
//        }
//    }
////    int ms = (std::clock() - start) / (double) (CLOCKS_PER_SEC / 100000);
////    cout << "Finished find_street_ids_from_name in: " << ms << "ms" << std::endl;
//    //Final Return
//    return streetsWithThisName;
//
//}

//std::vector < unsigned > find_all_street_intersections(unsigned street_id) {
//    return street_intersections[street_id];
//}


//    Goes in load map
//    
//    for (unsigned i = 0; i < getNumberOfIntersections(); i++) {
//
//    }
//    /*------------------------------------------------------------------------------------------*/


////Returns all street segments for the given street
//std::vector < unsigned > find_street_street_segments(unsigned street_id) {
//    
//    //Diagnostic Message
//    
//    //cout << "Find_Street_street_segments has been called for: " << street_id << endl;
//
//    unsigned totalNumOfStreetSegs = getNumberOfStreetSegments(); //Getting total number if segs ti work with
//    std::vector<unsigned> streetStreetSegs; //Vector we are eventually going to return
//
//
//
//    //We cycle through all the segments on the map by ID (from 0 to totalNumOfStreetSegs-1)
//    for (unsigned Count = 0; Count < totalNumOfStreetSegs; Count++) {
//
//        StreetSegmentInfo segInfo = getStreetSegmentInfo(Count); //Temp variable to store seg info
//
//        //If the street Index within matches we add the seg to the vector
//        if (segInfo.streetID == street_id) {
//            streetStreetSegs.push_back(Count); //adding ID to vector
//
//        }
//
//
//    } 
//    //Diagnostic Message:
//    //cout << "find_street_street_segments Success" << endl;
//    //Final Return
//    
//    return streetStreetSegs;
//    
//   return street_street_segments[street_id];
//    
//}


//Returns street id(s) for the given street name
// If no street with this name exists , returns a 0 - length vector .


//////////////////////////
//OLD TEST CODE FOR MAIN//
//////////////////////////




//void endofmap(){
//    LatLon largest(-180,-180);
//    LatLon smallest(180,180);
//    unsigned numberofPOI=getNumberOfPointsOfInterest();
//    vector<unsigned> interestvect;
//    for(unsigned k=0;k<numberofPOI;k++){
//
//        interestvect.push_back(k);
//        
//
//    }
//    unsigned numberofI=getNumberOfIntersections();
//    vector<unsigned> intersectvect;
//    for(unsigned k=0;k<numberofI;k++){
//
//
//
//        intersectvect.push_back(k);
//
//    };
//    for(unsigned i=0;i<interestvect.size();i++){
//        if(getPointOfInterestPosition(interestvect[i]).lat()>largest.lat())
//            largest.lat()=getPointOfInterestPosition(interestvect[i]).lat;
//        if(getPointOfInterestPosition(interestvect[i]).lon()>largest.lon())
//            largest.lon()=getPointOfInterestPosition(interestvect[i]).lon();
//        if(getPointOfInterestPosition(interestvect[i]).lat()<smallest.lat())
//            smallest.lat()=getPointOfInterestPosition(interestvect[i]).lat;
//        if(getPointOfInterestPosition(interestvect[i]).lon()<smallest.lon())
//            smallest.lon()=getPointOfInterestPosition(interestvect[i]).lon();
//    };
//    for(unsigned i=0;i<intersectvect.size();i++){
//        if(getIntersectionPosition(interestvect[i]).lat()>largest.lat())
//            largest.lat()=getIntersectionPosition(interestvect[i]).lat;
//        if(getIntersectionPosition(interestvect[i]).lon()>largest.lon())
//            largest.lon()=getIntersectionPosition(interestvect[i]).lon();
//        if(getIntersectionPosition(interestvect[i]).lat()<smallest.lat())
//            smallest.lat()=getIntersectionPosition(interestvect[i]).lat;
//        if(getIntersectionPosition(interestvect[i]).lon()<smallest.lon())
//            smallest.lon()=getIntersectionPosition(interestvect[i]).lon();
//    };
//    cout<<smallest.lat()<<"."<<smallest.lon()<<"  "<<largest.lat()<<"."<<largest.lon()<<endl;
//}



//    /*
//    //bool areconnected = true;
//    //areconnected = are_directly_connected (5000, 5001);
//    //cout << areconnected<<endl;
//    
////    */
////    vector<unsigned> testVector;
////    testVector = find_adjacent_intersections(42118);
////    for (unsigned i = 0; i < testVector.size(); i++) {
////        cout << "lol: "<<testVector[i]<<endl;
////    }
////    
//    
////    /* TEST FOR find_street_ids_from_name */
////    vector <unsigned> street_ids = find_street_ids_from_name ("Yonge Street");
////    for (unsigned i = 0; i < street_ids.size(); i++) {
////        cout << street_ids[i]<<endl;
////    }
//     
//    
//    /*TEST FOR find_intersection_street_segments
//    vector<unsigned> street_segments = find_intersection_street_segments (2);
//    for (unsigned i = 0; i < street_segments.size();i++) {
//        cout<< "street segments: " ;
//        cout<<street_segments[i]<<endl;
//    }
//     */
//    /*
//    //TEST FOR find_intersection_street_names
//    vector <string> street_names = find_intersection_street_names (2000);
//    cout << "street names: "<<endl;
//    for (unsigned i = 0; i < street_names.size(); i++) {
//        cout << street_names[i]<<endl;
//    }
//     */
//    
//    //TEST FOR find_intersection_ids_from_street_names
////    vector <unsigned>intersection_ids = find_intersection_ids_from_street_names("Highways 27, 401, 427", "Eglinton Avenue West");
////    for (unsigned i = 0; i < intersection_ids.size(); i++) {
////        cout << intersection_ids[i]<<endl;
////    }
//   
//    
//////    
////    Test for find_street_IDs_from_name
//    vector <unsigned>Street__IDs = find_street_ids_from_name("Bloor Street");
//        for (unsigned i = 0; i < Street__IDs.size(); i++) {
//        cout << "StreetID: " << Street__IDs[i]<<endl;
//    }
////    
////    vector <unsigned>Street__IDs2 = find_street_ids_from_name("Eglinton Avenue West");
////        for (unsigned i = 0; i < Street__IDs2.size(); i++) {
////        cout << "StreetID: " << Street__IDs2[i]<<endl;
////    }
////    
////    
////    //Test for find_street_street_segments
////    vector <unsigned>Street_Segment_IDs = find_street_street_segments(9098);
////    for (unsigned i = 0; i < Street_Segment_IDs.size(); i++) {
////        cout << "Vector length: " << Street_Segment_IDs.size() << endl;  
////        cout << "Street Segment ID is: " << Street_Segment_IDs[i]<<endl;
//////        cout << "Street Segment length is: " << find_street_segment_length(Street_Segment_IDs[i]) << endl;
//////    }
////    
////    double actual;
////
////        actual = find_street_length(9098);
////        cout << "Actual: " << actual << endl;
////
////
//////    
////    
////    
////  // Test for find_all_street_intersections
////    vector <unsigned>Street_Inter_IDs = find_all_street_intersections(11357);
////        for (unsigned i = 0; i < Street_Inter_IDs.size(); i++) {
////        cout << "Street Int ID is: " << Street_Inter_IDs[i]<<endl;
////    }
////    
////    vector <unsigned>Street_Inter_IDs2 = find_all_street_intersections(1530);
////        for (unsigned i = 0; i < Street_Inter_IDs2.size(); i++) {
////        cout << "Street Int ID is: " << Street_Inter_IDs2[i]<<endl;
////    }
////    
////
////    
////    
//    
////    std::vector<unsigned> actual = find_street_street_segments(15291);
////    for (unsigned i = 0; i < actual.size(); i++) {
////       cout << "Street Int ID is: " << actual[i]<<endl;
////    }
////    
//    
//    //double actual = find_distance_between_two_points(LatLon(43.79279327392578, -79.40152740478516), LatLon(43.78813934326172, -79.37289428710938));
//    
//    //Clean-up the map related data structures
//
////    std::cout.precision(10);
////    double length=find_street_length(14456);
////    cout<<length<<endl;
//
////    unsigned index=find_closest_intersection(LatLon(43.7193603515625, -79.52051544189453));
////    cout<<index<<"."<<index<<endl;