///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//
///* 
// * File:   HashTable.h
// * Author: linnaihs
// *
// * Created on February 5, 2017, 3:58 PM
// */
//
//#ifndef HASHTABLE_H
//#define HASHTABLE_H
//#include <LatLon.h>
//#include <vector>
//#include <math.h>
//#include <GlobalVariables.h>
//using namespace std;
//
////sizex and size y are # increment per side  hash is the # of increment from base point 
////basex and basey are the verticies with smallest abs(x) and abs(y) value)
//
//int findHashValue(LatLon my_position,const double basey_,const double basex_,const double increment_,const double averagelat_,const int sizex_ );
//double findXfromLatLon(LatLon my_position);
//double findYfromLatLon(LatLon my_position);
//double findShortestDistanceInOneSquare(int HashValue,LatLon my_position,int& index,const vector<vector<unsigned>> HashTable,const vector<LatLon> position_vector,double& shortest);
//vector <int> findNewVerticies(LatLon my_position, double shortest_distance);
//double searchThroughRectangleForShortestDistance(vector<int> ThreeVerticies,LatLon my_position,int& index,const vector<vector<unsigned>> HashTable,const vector<LatLon> position_vector,double& shortest);
//
//#endif /* HASHTABLE_H */
//
