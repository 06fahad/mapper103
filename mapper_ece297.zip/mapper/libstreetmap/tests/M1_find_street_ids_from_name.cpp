#include <algorithm>
#include <set>
#include <unittest++/UnitTest++.h>
#include "unit_test_util.h"
#include "m1.h"
#include "StreetsDatabaseAPI.h"

using ece297test::relative_error;
using namespace std;

std::vector<unsigned> find_street_ids_from_name2(std::string street_name);

struct MapFixture {
    MapFixture() {
        //Load the map
        load_map("/cad2/ece297s/public/maps/toronto_canada.streets.bin");

        //Initialize random number generators
        rng = std::minstd_rand(3);
        rand_street = std::uniform_int_distribution<unsigned>(1, getNumberOfStreets()-1);
    }

    ~MapFixture() {
        //Clean-up
        close_map();
    }

    std::minstd_rand rng;
    std::uniform_int_distribution<unsigned> rand_street;
};

std::vector<unsigned> find_street_ids_from_name2(std::string street_name) {

    std::vector<unsigned> streetsWithThisName;
    for (unsigned i = 0; i < getNumberOfStreets(); i++) {

        string tempName = getStreetName(i);
        if (street_name == tempName) {
            streetsWithThisName.push_back(i);
        }
    }

    return streetsWithThisName;

}

SUITE(street_queries_perf_public_toronto_canada) {

    TEST_FIXTURE(MapFixture, find_street_ids_from_name) {
        
        //Verify Functionality
        std::vector<unsigned> expected;
        std::vector<unsigned> actual;
        
        //Standard base case 1 (One street index)
        expected = {8537};
        actual = find_street_ids_from_name("Airdrie Drive");
        std::sort(actual.begin(), actual.end());
        CHECK_EQUAL(expected, actual);
        
        //Standard base case 2
        expected = {5789};
        actual = find_street_ids_from_name("Bloor Street");
        std::sort(actual.begin(), actual.end());
        CHECK_EQUAL(expected, actual);
        
        //"Unknown" case
        expected = {0};
        actual = find_street_ids_from_name("<unknown>");
        std::sort(actual.begin(), actual.end());
        CHECK_EQUAL(expected, actual);
        
        //No such street case
        expected = {};
        actual = find_street_ids_from_name("ECE 297 Street");
        std::sort(actual.begin(), actual.end());
        CHECK_EQUAL(expected, actual);
        
        //Multiple streets case
        expected = {260, 273, 925, 4590};
        actual = find_street_ids_from_name("Spadina Avenue");
        std::sort(actual.begin(), actual.end());
        CHECK_EQUAL(expected, actual);
        
        
        //Generate random cases for functional testing not used for performance testing
        //1000 test cases
        std::vector<std::string> street_names_2;
        for(size_t i = 0; i < 1000; i++) {
            
            unsigned street_id1 = rand_street(rng);
            street_names_2.push_back(getStreetName(street_id1));
        }
        
        {
            std::vector<unsigned> result;
            std::vector<unsigned> answer;
            for(size_t i = 0; i < 1000; i++) {
                
                answer = find_street_ids_from_name2(street_names_2[i]);
                result = find_street_ids_from_name(street_names_2[i]);
            }
            
            CHECK_EQUAL(answer, result);
            
            result.clear();
        }
        
        //Generate random inputs
        //10000000 test cases
        std::vector<std::string> street_names_1;
        for(size_t i = 0; i < 1000000; i++) {
            unsigned street_id1 = rand_street(rng);
            street_names_1.push_back(getStreetName(street_id1));
        }
        {
            //Timed Test
            ECE297_TIME_CONSTRAINT(350 + 250); //Takes into account the time to load map ~330ms and 250ns per call for 1 million calls
            std::vector<unsigned> result;
            for(size_t i = 0; i < 1000000; i++) {
                result = find_street_ids_from_name(street_names_1[i]);
            }
        }
    } //find_street_ids_from_name

} 
