/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   M1_find_street_ids_from_name.h
 * Author: zhan2860
 *
 * Created on February 5, 2017, 10:16 PM
 */

#ifndef M1_FIND_STREET_IDS_FROM_NAME_H
#define M1_FIND_STREET_IDS_FROM_NAME_H

class M1_find_street_ids_from_name {
public:
    M1_find_street_ids_from_name();
    M1_find_street_ids_from_name(const M1_find_street_ids_from_name& orig);
    virtual ~M1_find_street_ids_from_name();

private:

};

#endif /* M1_FIND_STREET_IDS_FROM_NAME_H */

